import React from 'react';

const Loading = () => {
    return (
        <div className='text-white'>Loading...</div>
    ) 
}

export default Loading;