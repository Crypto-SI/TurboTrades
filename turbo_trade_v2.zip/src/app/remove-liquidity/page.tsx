"use client"
import React from 'react';

const Home = () => {

  return (
    <div className="flex-grow flex justify-center items-center">
      Remove liquidity
    </div>
  )
}

export default Home;